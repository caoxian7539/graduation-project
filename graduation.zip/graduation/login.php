<!DOCTYPE html>
<html lang="en">
  	<head>
    	<meta charset="utf-8">
    	<title>login</title>
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<link rel="stylesheet" href="bootstrap-3.0.0/dist/css/bootstrap.css">
    	<link rel="stylesheet" href="login.css">
     <!--  <style type="text/css">
        body
        {
        background:url(images/nanjing_fengye.jfif);
        background-size: cover;
        background-repeat: no-repeat;
        }
      </style> -->
  	</head>

  	<body>
  	<main>
  		<div class="container">
          <div class="row">
            <div class="col-lg-5">
  				  <img style="float:right;" src="images/logo-mid.jpg" alt="logo">
  			</div>

  		    <div class="col-lg-5">
  		  	<h2>Login Your Maxore Account</h2>
  				<form action="login_validation.php" method="POST">
    			<div class="form-group">
     			<label for="email">Email:</label>
      			<input type="email" class="form-control" placeholder="Enter email" name="email">
    			</div>
    			<div class="form-group">
      			<label for="password1">Password:</label>
      			<input type="password" class="form-control" placeholder="Enter password" name="password1">
    			</div>
    			<div class="checkbox">
      			<label><input type="checkbox" name="remember"> Remember me</label>
    			</div>
          <p>Don't have an account<a href="createAccount.php">Create acount</a></p>
    			<button type="submit" class="btn btn-success">Submit</button>
  				</form>
  		    </div>
  		  </div>
  		</div>
  			





  	</main>	
	</body>
  </html>