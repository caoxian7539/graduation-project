<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="utf-8">
      <title>Chang sha</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="bootstrap-3.0.0/dist/css/bootstrap.css">
      <link rel="stylesheet" href="login.css">
    </head>

    <body>
    <main>
      <div class="container">
          <div class="row">
            <div class="col-lg-5">
            <img style="float:right;" src="images/logo-mid.jpg" alt="logo">
          
        </div>

          <div class="col-lg-5">
          <h2>Create Your Account</h2>
          <form action="create_validation.php" method="POST" role="form">
           
          <div class="form-group">
          <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
          </div>
          <div class="form-group">
          <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter name" name="name">
          </div> 
          <div class="form-group">
            <label for="password1">Password:</label>
            <input type="password" class="form-control" id="password1" placeholder="Enter password" name="password1">
          </div>
          <div class="form-group">
            <label for="password2">Confirm Password:</label>
            <input type="password" class="form-control" id="password2" placeholder="Confirm your password" name="password2">
          </div>
          <div class="checkbox">
            <label><input type="checkbox" name="remember"> Remember me</label>
          </div>
          <p>Already have an account<a href="login.php"> Sign in</a></p>
          <button type="submit" class="btn btn-success">Submit</button>
          </form>
          </div>
        </div>
      </div>
        





    </main>>  
  </body>>
  