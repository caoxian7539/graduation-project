<?php
	session_start();
	$email=$_POST["email"];
	$psw=$_POST["password1"];
	$name=$_POST["name"];
	
	$conPsw=$_POST["password2"];
	if(!empty($email)||!empty($psw)||!empty($name)||!empty($conPsw)){

		$host = "localhost";
		$dbUsername = "root";
		$dbPassword = "";
		$dbname = "project_database";
		$con = mysqli_connect($host, $dbUsername,$dbPassword,$dbname);

		if(mysqli_connect_error()){
			die("Connect Error");
		}else{
			if($psw===$conPsw){
			$SELECT = "SELECT * From account WHERE email='$email'";
			$result = mysqli_query($con,$SELECT);
			$num = mysqli_num_rows($result);
			if($num == 1){
				echo 'email already taken, please use another one';
			}else{
			$INSERT = "INSERT Into account(email, name, password) values('$email','$name','$psw')";

			mysqli_query($con, $INSERT);
			echo "<p>Account created</p>";
			echo "<a href='login.php'>Login</a>";	
			}}			
				
			    
		    else{
				echo "please confirm your password";
			    }
		    }
	}
    else{
		echo "you must enter all information";
	}
?>