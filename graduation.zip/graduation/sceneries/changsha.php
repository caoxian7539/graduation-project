<!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Homepage</title>
      	<meta charset="utf-8">
      	<meta name="viewport" content="width=device-width, initial-scale=1.0">
      	<link rel="stylesheet" href="../bootstrap-3.0.0/dist/css/bootstrap.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style type="text/css">
          
          .navbar-nav>img{
            margin-top: 0;
            margin-left: 600px;
           float: left;
         }

         .navbar-nav > li>a{
          display: block;
          height:72px;
          padding-top: 25px;
          color: red;
          font-size: 20px;
         }
         
        </style>
  </head>

    	<body>
        <nav class="navbar navbar-default">
          <div class="container-fluid">
          <ul class="nav navbar-nav">
            <img class="logo" src="../images/logo-small.png">
            <li><a href="../home.php">Home</a></li>
            <li class="dropdown">
              <a class="active" class="dropdown-toggle" data-toggle="dropdown" href="#">Sceneries
              <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li class="active"><a href="#">Changsha</a></li>
                  <li><a href="#">Shanghai</a></li>
                  <li><a href="#">Xi An</a></li>
                  </ul>
            </li>
           
            <li><a href="#">Travel Guides</a></li>
            <li><a href="#">Foods</a></li>
            <li><a href="#">to be plan</a></li>
            <li><a href="#">to be plan</a></li>
          </ul>

          <!-- <span class="glyphicon glyphicon-log-in"></span>unrealized -->
          <ul class="nav navbar-nav navbar-right"> 
          <?php
          session_start();
           if(isset($_SESSION['name'])){
            echo "<li><a href='login.php'></span>Log out</a></li>";
           }
           else{
            echo "<li><a href='createAccount.php'></span>Sign Up</a></li>
            <li><a href='login.php'> Login</a></li>";
          }
          ?>
          </ul>
        </div>
      </nav>

      <div class="container marketing">
        <div class="row featurette">
         <div class="col-md-7">
          <h2 class="featurette-heading">Juzizhou Island <span class="text-muted">It'll blow your mind.</span></h2>
          <p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
        </div>
        <div class="col-md-5">
          <img class="featurette-image img-responsive" src="../images/changsha-juzizhou2.png"  alt="changsha-juzizhou3" >
        </div>
      </div>

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-5">
          <img class="featurette-image img-responsive" src="../images/changsha-yuelushan.jpg"  alt="changsha yuelushan">
        </div>
        <div class="col-md-7">
          <h2 class="featurette-heading">Yuelu Mountain <span class="text-muted">You must climb to the top once</span></h2>
          <p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
        </div>
      </div>

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-5">
          <img class="featurette-image img-responsive" src="../images/changsha-taipingjie2.jpeg"  alt="changsha taipingjie">
        </div>
        <div class="col-md-7">
          <h2 class="featurette-heading">Peace$Love Street <span class="text-muted">Unforgottable Foods</span></h2>
          <p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
        </div>
      </div>

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-5">
          <img class="featurette-image img-responsive" src="../images/changsha-chayan.jpg"  alt="changsha chayan">
        </div>
        <div class="col-md-7">
          <h2 class="featurette-heading">Tea Smile <span class="text-muted">A cup of tea can make smile one day</span></h2>
          <p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
        </div>
      </div>

      <hr class="featurette-divider">

    </div>

</body>
</html>