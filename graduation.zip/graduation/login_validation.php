<?php
	session_start();

	$email=$_POST["email"];
	$psw=$_POST["password1"];

	if(!empty($email)||!empty($psw)){

		$host = "localhost";
		$dbUsername = "root";
		$dbPassword = "";
		$dbname = "project_database";
		$con = mysqli_connect($host, $dbUsername,$dbPassword,$dbname);
		$SELECT = "SELECT * From account WHERE email='$email' && password='$psw'";

		$result = mysqli_query($con,$SELECT);

		$nrows = mysqli_num_rows($result);
		if($nrows == 1){
			while($row = mysqli_fetch_array($result)){
				$_SESSION['email'] = $row['email'];
				$_SESSION['name'] = $row['name'];
				header('location:home.php');
				echo $email . ': ' . $name . '<br>';
			}
			
		}else{
			echo "<script>alert('wrong email or password')</script>";
			echo "<a href='login.php'>Go back to login page</a>";
		}
	}
?>