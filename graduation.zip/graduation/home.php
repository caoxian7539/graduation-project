  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Homepage</title>
      	<meta charset="utf-8">
      	<meta name="viewport" content="width=device-width, initial-scale=1.0">
      	<link rel="stylesheet" href="bootstrap-3.0.0/dist/css/bootstrap.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style type="text/css">
          
          .navbar-nav>img{
            margin-top: 0;
            margin-left: 600px;
           float: left;
         }

         .navbar-nav > li>a{
          display: block;
          height:72px;
          padding-top: 25px;
          color: red;
          font-size: 20px;
         }
         
        </style>
  </head>

    	<body>
        <nav class="navbar navbar-default">
          <div class="container-fluid">
          <ul class="nav navbar-nav">
            <img class="logo" src="images/logo-small.png">
            <li class="active"><a href="home.php">Home</a></li>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">Sceneries
              <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="sceneries/changsha.php">Changsha</a></li>
                  <li><a href="#">Shanghai</a></li>
                  <li><a href="#">Xi An</a></li>
                  </ul>
            </li>
           
            <li><a href="#">Travel Guides</a></li>
            <li><a href="#">Foods</a></li>
            <li><a href="#">to be plan</a></li>
            <li><a href="#">to be plan</a></li>
          </ul>

          <!-- <span class="glyphicon glyphicon-log-in"></span>unrealized -->
          <ul class="nav navbar-nav navbar-right"> 
          <?php
          session_start();
           if(isset($_SESSION['name'])){
            echo "<li><a href='login.php'></span>Log out</a></li>";
           }
           else{
            echo "<li><a href='createAccount.php'></span>Sign Up</a></li>
            <li><a href='login.php'> Login</a></li>";
          }
          ?>
          </ul>
        </div>
      </nav>
    		
        
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner">

        <div class="item active">
          <img src="images/changsha-juzizhou.jpg" alt="changsha-juzizhou" style="width:100%;max-width: 100%;
          max-height: 600px;">
          <div class="carousel-caption">
            <h3>Changsha Juzizhou Island</h3>
            <p>A Place Where Great Leaders Grew</p>
          </div>
        </div>

        <div class="item">
          <img src="images/shanghai-intro.jpg" alt="shanghai-intro" style="width:100%;max-width: 100%;
          max-height: 600px;">
          <div class="carousel-caption">
            <h3>Shanghai</h3>
            <p>A Magic City</p>
          </div>
        </div>
      
        <div class="item">
          <img src="images/lasa-intro.png" alt="lasa-intro" style="width:100%;max-width: 100%;
          max-height: 600px;">
          <div class="carousel-caption">
            <h3>Lasa</h3>
            <p>Shrine of Pilgrims</p>
          </div>
        </div>
    
      

      <!-- Left and right controls -->
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>


       <div class="container marketing">

      <!-- Three columns of text below the carousel -->
      <div class="row">
        <div class="col-lg-4">
          <img class="thumbnail" src="images/changsha-yuelushan.jpg " alt="Yuelu Mountain">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Praesent commodo cursus magna.</p>
          <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="thumbnail" src="images/shanghai-dongfangmingzhu.jpg" alt="Oriental Pearl">
          <h2>Heading</h2>
          <p>Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cras mattis consectetur purus sit amet fermentum. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh.</p>
          <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="thumbnail" src="images/changsha-taipingjie.jpg" alt="Peace&Love Street" style="width: :419.33px;height: : 282.88px">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->
        
    
    </body>
    </html>